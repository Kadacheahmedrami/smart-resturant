"use client"

import { useState } from "react"
import { Wifi, WifiOff } from "lucide-react"

import { Button } from "@/components/ui/button"
import { ESP32ConnectionDialog } from "@/components/esp32-connection-dialog"
import { useESP32 } from "@/lib/esp32-context"

export function ESP32StatusButton() {
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const { isConnected } = useESP32()

  return (
    <>
      <Button
        variant="outline"
        size="sm"
        className={`gap-2 ${isConnected ? "border-green-500 text-green-600" : "border-red-300 text-red-500"}`}
        onClick={() => setIsDialogOpen(true)}
      >
        {isConnected ? (
          <>
            <Wifi className="h-4 w-4" />
            <span className="hidden sm:inline">ESP32 Connected</span>
            <span className="sm:hidden">ESP32</span>
          </>
        ) : (
          <>
            <WifiOff className="h-4 w-4" />
            <span className="hidden sm:inline">ESP32 Disconnected</span>
            <span className="sm:hidden">ESP32</span>
          </>
        )}
      </Button>

      <ESP32ConnectionDialog isOpen={isDialogOpen} onClose={() => setIsDialogOpen(false)} />
    </>
  )
}
