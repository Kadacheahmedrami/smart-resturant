"use client"

import { useEffect, useState } from "react"
import Link from "next/link"
import { ArrowLeft, Home } from "lucide-react"

import { Button } from "@/components/ui/button"
import { StatusDisplay } from "@/components/status-display"
import { StatusBadge } from "@/components/status-badge"
import { StatusAnimation } from "@/components/status-animation"
import { useToast } from "@/hooks/use-toast"

// This would be set to your ESP32's IP address
const ESP_IP = "192.168.1.100" // Replace with your actual ESP32 IP

export default function ClientPage() {
  const [status, setStatus] = useState("PENDING")
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const { toast } = useToast()

  useEffect(() => {
    const fetchStatus = async () => {
      try {
        // In a real app, you'd use the actual ESP32 IP
        // const response = await fetch(`http://${ESP_IP}/status`)

        // For demo purposes, we'll simulate the API response
        const mockResponse = {
          status: ["PENDING", "ACCEPTED", "REJECTED", "READY"][Math.floor(Math.random() * 4)],
        }

        // Simulate API delay
        await new Promise((resolve) => setTimeout(resolve, 500))

        setStatus(mockResponse.status)
        setLoading(false)
        setError(null)
      } catch (err) {
        console.error("Error fetching status:", err)
        setError("Failed to connect to the server. Please try again later.")
        setLoading(false)
        toast({
          title: "Connection Error",
          description: "Could not connect to the order system.",
          variant: "destructive",
        })
      }
    }

    fetchStatus()

    // Poll for updates every 3 seconds
    const intervalId = setInterval(fetchStatus, 3000)

    return () => clearInterval(intervalId)
  }, [toast])

  return (
    <div className="min-h-screen flex flex-col">
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center justify-between">
          <div className="flex items-center gap-2">
            <Link href="/">
              <Button variant="ghost" size="icon">
                <Home className="h-5 w-5" />
                <span className="sr-only">Home</span>
              </Button>
            </Link>
            <h1 className="text-xl font-heading">Client View</h1>
          </div>
          <Link href="/">
            <Button variant="ghost" size="sm" className="gap-1">
              <ArrowLeft className="h-4 w-4" />
              Back to Home
            </Button>
          </Link>
        </div>
      </header>
      <main className="flex-1 container py-10">
        <div className="max-w-3xl mx-auto">
          <div className="mb-8 text-center">
            <h2 className="text-3xl font-heading mb-2">Your Order Status</h2>
            <p className="text-muted-foreground">Track the progress of your order in real-time</p>
          </div>

          {loading ? (
            <div className="flex flex-col items-center justify-center p-12">
              <div className="w-16 h-16 border-4 border-primary/30 border-t-primary rounded-full animate-spin"></div>
              <p className="mt-4 text-muted-foreground">Loading status...</p>
            </div>
          ) : error ? (
            <div className="bg-destructive/10 border border-destructive/30 rounded-lg p-6 text-center">
              <p className="text-destructive font-medium">{error}</p>
              <Button variant="outline" className="mt-4" onClick={() => window.location.reload()}>
                Retry Connection
              </Button>
            </div>
          ) : (
            <div className="space-y-8">
              <div className="flex justify-center">
                <StatusBadge status={status} size="lg" />
              </div>

              <StatusAnimation status={status} />

              <StatusDisplay status={status} />

              {status === "READY" && (
                <div className="bg-primary/10 border border-primary/30 rounded-lg p-6 text-center mt-8 animate-fade-in">
                  <h3 className="text-xl font-semibold mb-2">Your order is ready!</h3>
                  <p className="mb-4">Please proceed to the counter to collect your order.</p>
                  <Button>Confirm Pickup</Button>
                </div>
              )}
            </div>
          )}
        </div>
      </main>
      <footer className="border-t py-6">
        <div className="container flex flex-col items-center justify-between gap-4 md:flex-row">
          <p className="text-center text-sm leading-loose text-muted-foreground md:text-left">
            © 2024 Gourmet Status. All rights reserved.
          </p>
        </div>
      </footer>
    </div>
  )
}
