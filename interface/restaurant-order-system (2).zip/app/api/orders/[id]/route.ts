import { NextResponse } from "next/server"
import { orders } from "@/lib/mock-data"

export async function GET(request: Request, { params }: { params: { id: string } }) {
  const id = params.id

  // In a real app, you would fetch this from your database using Prisma
  // const order = await prisma.order.findUnique({
  //   where: { id },
  //   include: { items: true }
  // })

  const order = orders.find((order) => order.id === id)

  if (!order) {
    return NextResponse.json({ error: "Order not found" }, { status: 404 })
  }

  return NextResponse.json(order)
}

export async function PATCH(request: Request, { params }: { params: { id: string } }) {
  try {
    const id = params.id
    const body = await request.json()

    // Validate request body
    if (!body.status) {
      return NextResponse.json({ error: "Status is required" }, { status: 400 })
    }

    // In a real app, you would update this in your database using Prisma
    // const updatedOrder = await prisma.order.update({
    //   where: { id },
    //   data: { status: body.status, updatedAt: new Date() },
    //   include: { items: true }
    // })

    // Update in-memory storage
    const orderIndex = orders.findIndex((order) => order.id === id)

    if (orderIndex === -1) {
      return NextResponse.json({ error: "Order not found" }, { status: 404 })
    }

    orders[orderIndex] = {
      ...orders[orderIndex],
      status: body.status,
      updatedAt: new Date().toISOString(),
    }

    return NextResponse.json(orders[orderIndex])
  } catch (error) {
    console.error("Error updating order:", error)
    return NextResponse.json({ error: "Failed to update order" }, { status: 500 })
  }
}
