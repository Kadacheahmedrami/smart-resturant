"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { CheckCircle, CreditCard } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { StatusBadge } from "@/components/status-badge"
import { StarRating } from "@/components/star-rating"
import { useToast } from "@/hooks/use-toast"
import { useESP32 } from "@/lib/esp32-context"
import { pusherClient } from "@/lib/pusher"
import { PaymentDialog } from "@/components/payment-dialog"
import type { Order } from "@/types/order"

interface OrderClientProps {
  orderPromise: Promise<Order | null>
  orderId: string
}

export function OrderClient({ orderPromise, orderId }: OrderClientProps) {
  const [order, setOrder] = useState<Order | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [isPaid, setIsPaid] = useState(false)
  const [isPaymentDialogOpen, setIsPaymentDialogOpen] = useState(false)
  const { toast } = useToast()
  const { isConnected, sendStatus } = useESP32()

  useEffect(() => {
    // Load initial order data from the promise
    orderPromise
      .then((data) => {
        setOrder(data)
        setLoading(false)

        // Check if the order has a payment status stored in localStorage
        const paymentStatus = localStorage.getItem(`order_${orderId}_paid`)
        if (paymentStatus === "true") {
          setIsPaid(true)
        }

        // If ESP32 is connected, send the status
        if (isConnected && data?.status) {
          sendStatus(data.status)
        }
      })
      .catch((err) => {
        console.error("Error loading order:", err)
        setError("Failed to load order details")
        setLoading(false)
      })

    // Subscribe to Pusher channel for real-time updates
    const channel = pusherClient.subscribe(`order-${orderId}`)

    // Listen for order updates
    channel.bind("order-updated", (data: { order: Order }) => {
      setOrder(data.order)

      // If ESP32 is connected, send the status
      if (isConnected && data.order.status) {
        sendStatus(data.order.status)
      }

      toast({
        title: "Order Updated",
        description: `Your order status has been updated to ${data.order.status}`,
      })
    })

    // Listen for rating updates
    channel.bind("rating-updated", (data: { rating: any }) => {
      setOrder((prevOrder) => {
        if (!prevOrder) return null
        return { ...prevOrder, rating: data.rating }
      })
    })

    channel.bind("rating-created", (data: { rating: any }) => {
      setOrder((prevOrder) => {
        if (!prevOrder) return null
        return { ...prevOrder, rating: data.rating }
      })
    })

    return () => {
      // Unsubscribe from Pusher channel when component unmounts
      pusherClient.unsubscribe(`order-${orderId}`)
    }
  }, [orderPromise, orderId, toast, isConnected, sendStatus])

  const handlePayment = () => {
    setIsPaymentDialogOpen(true)
  }

  const completePayment = () => {
    setIsPaid(true)
    setIsPaymentDialogOpen(false)

    // Store payment status in localStorage
    localStorage.setItem(`order_${orderId}_paid`, "true")

    toast({
      title: "Payment Successful",
      description: "Thank you for your payment! Please rate your experience.",
    })
  }

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center p-12">
        <div className="w-16 h-16 border-4 border-primary/30 border-t-primary rounded-full animate-spin"></div>
        <p className="mt-4 text-muted-foreground">Loading status...</p>
      </div>
    )
  }

  if (error) {
    return (
      <div className="text-center py-12 border rounded-lg">
        <h3 className="text-xl font-semibold mb-2">Error</h3>
        <p className="text-muted-foreground mb-6">{error}</p>
        <Link href="/menu">
          <Button>Browse Menu</Button>
        </Link>
      </div>
    )
  }

  if (!order) {
    return (
      <div className="text-center py-12 border rounded-lg">
        <h3 className="text-xl font-semibold mb-2">Order not found</h3>
        <p className="text-muted-foreground mb-6">The order you're looking for doesn't exist.</p>
        <Link href="/menu">
          <Button>Browse Menu</Button>
        </Link>
      </div>
    )
  }

  const totalPrice = order.items.reduce((total, item) => total + item.price * item.quantity, 0)

  return (
    <div className="space-y-8">
      <div className="flex justify-center">
        <StatusBadge status={order.status} size="lg" />
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Order Details</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <h4 className="text-sm font-medium text-muted-foreground mb-1">Order ID</h4>
                <p className="font-mono text-sm">{order.id}</p>
              </div>
              <div>
                <h4 className="text-sm font-medium text-muted-foreground mb-1">Order Date</h4>
                <p className="text-sm">{new Date(order.createdAt).toLocaleString()}</p>
              </div>
            </div>

            <div>
              <h4 className="text-sm font-medium text-muted-foreground mb-2">Items</h4>
              <div className="space-y-2">
                {order.items.map((item) => (
                  <div key={item.id} className="flex justify-between py-2 border-b last:border-0">
                    <div>
                      <p className="font-medium">{item.name}</p>
                      {item.notes && <p className="text-xs text-muted-foreground">{item.notes}</p>}
                    </div>
                    <div className="text-sm">
                      {item.quantity} x ${item.price.toFixed(2)}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="flex justify-between pt-4 border-t">
              <p className="font-bold">Total</p>
              <p className="font-bold">${totalPrice.toFixed(2)}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {order.status === "ACCEPTED" && (
        <div className="bg-green-100 dark:bg-green-900/30 border border-green-200 dark:border-green-900/50 rounded-lg p-6 text-center">
          <h3 className="text-xl font-semibold mb-2 text-green-800 dark:text-green-400">
            Your order has been accepted!
          </h3>
          <p className="text-green-700 dark:text-green-300 mb-4">The restaurant is preparing your food.</p>
        </div>
      )}

      {order.status === "READY" && (
        <div className="space-y-8">
          <div className="bg-blue-100 dark:bg-blue-900/30 border border-blue-200 dark:border-blue-900/50 rounded-lg p-6 text-center">
            <h3 className="text-xl font-semibold mb-2 text-blue-800 dark:text-blue-400">
              Your order is ready for pickup!
            </h3>
            <p className="text-blue-700 dark:text-blue-300 mb-4">
              Please proceed to the counter to collect your order.
            </p>
          </div>

          {!isPaid && (
            <Card>
              <CardHeader>
                <CardTitle>Payment Required</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <p className="font-medium">Total Amount Due:</p>
                    <p className="text-xl font-bold">${totalPrice.toFixed(2)}</p>
                  </div>
                  <p className="text-sm text-muted-foreground">Please complete your payment to finalize your order.</p>
                </div>
              </CardContent>
              <CardFooter>
                <Button onClick={handlePayment} className="w-full gap-2">
                  <CreditCard className="h-4 w-4" />
                  Pay Now
                </Button>
              </CardFooter>
            </Card>
          )}

          {isPaid && !order.rating && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <CheckCircle className="h-5 w-5 text-green-500" />
                  Payment Complete
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="mb-6">
                  <p className="text-sm text-muted-foreground">
                    Thank you for your payment! Please rate your experience with us.
                  </p>
                </div>
                <StarRating orderId={order.id} onRatingSubmitted={() => {}} />
              </CardContent>
            </Card>
          )}

          {isPaid && order.rating && (
            <Card>
              <CardHeader>
                <CardTitle>Your Rating</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center mb-2">
                  <div className="flex">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <Star key={star} filled={star <= order.rating.score} />
                    ))}
                  </div>
                  <span className="ml-2 text-sm text-muted-foreground">
                    {order.rating.createdAt
                      ? `Submitted on ${new Date(order.rating.createdAt).toLocaleDateString()}`
                      : ""}
                  </span>
                </div>
                {order.rating.comment && <p className="text-sm italic">"{order.rating.comment}"</p>}
              </CardContent>
            </Card>
          )}
        </div>
      )}

      {order.status === "REJECTED" && (
        <div className="bg-red-100 dark:bg-red-900/30 border border-red-200 dark:border-red-900/50 rounded-lg p-6 text-center">
          <h3 className="text-xl font-semibold mb-2 text-red-800 dark:text-red-400">Your order has been rejected</h3>
          <p className="text-red-700 dark:text-red-300 mb-4">
            We're sorry, but the restaurant cannot fulfill your order at this time.
          </p>
          <Link href="/menu">
            <Button>Order Again</Button>
          </Link>
        </div>
      )}

      <PaymentDialog
        isOpen={isPaymentDialogOpen}
        onClose={() => setIsPaymentDialogOpen(false)}
        onPaymentComplete={completePayment}
        amount={totalPrice}
      />
    </div>
  )
}

function Star({ filled }: { filled: boolean }) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="20"
      height="20"
      viewBox="0 0 24 24"
      fill={filled ? "currentColor" : "none"}
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={filled ? "text-yellow-400" : "text-gray-300 dark:text-gray-600"}
    >
      <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" />
    </svg>
  )
}
