import { type NextRequest, NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"

export async function GET(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    // Await the params promise to get the actual values
    const { id } = await params

    const rating = await prisma.rating.findUnique({
      where: { id },
      include: {
        order: {
          include: {
            items: true,
          },
        },
      },
    })

    if (!rating) {
      return NextResponse.json({ error: "Rating not found" }, { status: 404 })
    }

    return NextResponse.json(rating)
  } catch (error) {
    console.error("Error fetching rating:", error)
    return NextResponse.json({ error: "Failed to fetch rating" }, { status: 500 })
  }
}

export async function DELETE(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    // Await the params promise to get the actual values
    const { id } = await params

    // Check if rating exists
    const rating = await prisma.rating.findUnique({
      where: { id },
    })

    if (!rating) {
      return NextResponse.json({ error: "Rating not found" }, { status: 404 })
    }

    // Delete the rating
    await prisma.rating.delete({
      where: { id },
    })

    return NextResponse.json({ message: "Rating deleted successfully" })
  } catch (error) {
    console.error("Error deleting rating:", error)
    return NextResponse.json({ error: "Failed to delete rating" }, { status: 500 })
  }
}
