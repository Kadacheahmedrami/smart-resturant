"use client"

import { useEffect, useState } from "react"
import Link from "next/link"
import { ArrowLeft, Home } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { StatusBadge } from "@/components/status-badge"
import { useToast } from "@/hooks/use-toast"
import type { Order } from "@/types/order"

export default function OrderPage({ params }: { params: { id: string } }) {
  const [order, setOrder] = useState<Order | null>(null)
  const [loading, setLoading] = useState(true)
  const { toast } = useToast()

  useEffect(() => {
    const fetchOrder = async () => {
      try {
        const response = await fetch(`/api/orders/${params.id}`)

        if (!response.ok) {
          throw new Error("Failed to fetch order")
        }

        const data = await response.json()
        setOrder(data)
        setLoading(false)
      } catch (err) {
        console.error("Error fetching order:", err)
        setLoading(false)
        toast({
          title: "Error",
          description: "Failed to fetch order details",
          variant: "destructive",
        })
      }
    }

    fetchOrder()

    // Poll for updates every 5 seconds
    const intervalId = setInterval(fetchOrder, 5000)

    return () => clearInterval(intervalId)
  }, [params.id, toast])

  const totalPrice = order?.items.reduce((total, item) => total + item.price * item.quantity, 0) || 0

  return (
    <div className="min-h-screen flex flex-col">
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center justify-between">
          <div className="flex items-center gap-2">
            <Link href="/">
              <Button variant="ghost" size="icon">
                <Home className="h-5 w-5" />
                <span className="sr-only">Home</span>
              </Button>
            </Link>
            <h1 className="text-xl font-bold">Order #{params.id}</h1>
          </div>
          <Link href="/orders">
            <Button variant="ghost" size="sm" className="gap-1">
              <ArrowLeft className="h-4 w-4" />
              All Orders
            </Button>
          </Link>
        </div>
      </header>
      <main className="flex-1 container py-10">
        <div className="max-w-3xl mx-auto">
          <div className="mb-8 text-center">
            <h2 className="text-3xl font-bold mb-2">Order Status</h2>
            <p className="text-muted-foreground">Track the progress of your order in real-time</p>
          </div>

          {loading ? (
            <div className="flex flex-col items-center justify-center p-12">
              <div className="w-16 h-16 border-4 border-primary/30 border-t-primary rounded-full animate-spin"></div>
              <p className="mt-4 text-muted-foreground">Loading status...</p>
            </div>
          ) : order ? (
            <div className="space-y-8">
              <div className="flex justify-center">
                <StatusBadge status={order.status} size="lg" />
              </div>

              <Card>
                <CardHeader>
                  <CardTitle>Order Details</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <h4 className="text-sm font-medium text-muted-foreground mb-1">Order ID</h4>
                        <p className="font-mono text-sm">{order.id}</p>
                      </div>
                      <div>
                        <h4 className="text-sm font-medium text-muted-foreground mb-1">Order Date</h4>
                        <p className="text-sm">{new Date(order.createdAt).toLocaleString()}</p>
                      </div>
                    </div>

                    <div>
                      <h4 className="text-sm font-medium text-muted-foreground mb-2">Items</h4>
                      <div className="space-y-2">
                        {order.items.map((item, index) => (
                          <div key={index} className="flex justify-between py-2 border-b last:border-0">
                            <div>
                              <p className="font-medium">{item.name}</p>
                            </div>
                            <div className="text-sm">
                              {item.quantity} x ${item.price.toFixed(2)}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="flex justify-between pt-4 border-t">
                      <p className="font-bold">Total</p>
                      <p className="font-bold">${totalPrice.toFixed(2)}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {order.status === "ACCEPTED" && (
                <div className="bg-green-100 dark:bg-green-900/30 border border-green-200 dark:border-green-900/50 rounded-lg p-6 text-center">
                  <h3 className="text-xl font-semibold mb-2 text-green-800 dark:text-green-400">
                    Your order has been accepted!
                  </h3>
                  <p className="text-green-700 dark:text-green-300 mb-4">The restaurant is preparing your food.</p>
                </div>
              )}

              {order.status === "REJECTED" && (
                <div className="bg-red-100 dark:bg-red-900/30 border border-red-200 dark:border-red-900/50 rounded-lg p-6 text-center">
                  <h3 className="text-xl font-semibold mb-2 text-red-800 dark:text-red-400">
                    Your order has been rejected
                  </h3>
                  <p className="text-red-700 dark:text-red-300 mb-4">
                    We're sorry, but the restaurant cannot fulfill your order at this time.
                  </p>
                  <Link href="/menu">
                    <Button>Order Again</Button>
                  </Link>
                </div>
              )}
            </div>
          ) : (
            <div className="text-center py-12 border rounded-lg">
              <h3 className="text-xl font-semibold mb-2">Order not found</h3>
              <p className="text-muted-foreground mb-6">The order you're looking for doesn't exist.</p>
              <Link href="/menu">
                <Button>Browse Menu</Button>
              </Link>
            </div>
          )}
        </div>
      </main>
    </div>
  )
}
