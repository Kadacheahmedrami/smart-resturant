import { NextResponse } from "next/server"

// Mock menu data - in a real app, this would come from your database
const menuItems = [
  {
    id: 1,
    name: "Margherita Pizza",
    description: "Classic pizza with tomato sauce, mozzarella, and basil",
    price: 12.99,
    image: "/placeholder.svg?height=200&width=300",
    category: "Pizza",
  },
  {
    id: 2,
    name: "Pepperoni Pizza",
    description: "Pizza topped with pepperoni slices and cheese",
    price: 14.99,
    image: "/placeholder.svg?height=200&width=300",
    category: "Pizza",
  },
  {
    id: 3,
    name: "Caesar Salad",
    description: "Fresh romaine lettuce with Caesar dressing and croutons",
    price: 8.99,
    image: "/placeholder.svg?height=200&width=300",
    category: "Salad",
  },
  {
    id: 4,
    name: "Spaghetti Carbonara",
    description: "Pasta with creamy sauce, pancetta, and Parmesan cheese",
    price: 15.99,
    image: "/placeholder.svg?height=200&width=300",
    category: "Pasta",
  },
  {
    id: 5,
    name: "Grilled Salmon",
    description: "Fresh salmon fillet with lemon butter sauce and vegetables",
    price: 18.99,
    image: "/placeholder.svg?height=200&width=300",
    category: "Main Course",
  },
  {
    id: 6,
    name: "Chocolate Cake",
    description: "Rich chocolate cake with a scoop of vanilla ice cream",
    price: 7.99,
    image: "/placeholder.svg?height=200&width=300",
    category: "Dessert",
  },
]

export async function GET() {
  // In a real app, you would fetch this from your database using Prisma
  // const menuItems = await prisma.menuItem.findMany()

  return NextResponse.json(menuItems)
}
