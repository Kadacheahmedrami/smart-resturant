import { NextResponse } from "next/server"
import { v4 as uuidv4 } from "uuid"
import { orders } from "@/lib/mock-data"

export async function GET() {
  // In a real app, you would fetch this from your database using Prisma
  // const orders = await prisma.order.findMany({
  //   include: { items: true },
  //   orderBy: { createdAt: 'desc' }
  // })

  return NextResponse.json(orders)
}

export async function POST(request: Request) {
  try {
    const body = await request.json()

    // Validate request body
    if (!body.items || !Array.isArray(body.items) || body.items.length === 0) {
      return NextResponse.json({ error: "Invalid order items" }, { status: 400 })
    }

    // Create a new order
    const newOrder = {
      id: uuidv4(),
      status: "PENDING",
      items: body.items,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    }

    // In a real app, you would save this to your database using Prisma
    // const order = await prisma.order.create({
    //   data: {
    //     status: "PENDING",
    //     items: {
    //       create: body.items.map((item: any) => ({
    //         menuItemId: item.menuItemId,
    //         quantity: item.quantity,
    //         name: item.name,
    //         price: item.price
    //       }))
    //     }
    //   },
    //   include: { items: true }
    // })

    // Add to in-memory storage
    orders.push(newOrder)

    return NextResponse.json(newOrder, { status: 201 })
  } catch (error) {
    console.error("Error creating order:", error)
    return NextResponse.json({ error: "Failed to create order" }, { status: 500 })
  }
}
