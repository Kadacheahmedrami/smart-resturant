export interface OrderItem {
  name: string
  quantity: number
  price: number
  notes?: string
}

export interface Order {
  id: string
  status: string
  items: OrderItem[]
  createdAt: string
  updatedAt: string
}
