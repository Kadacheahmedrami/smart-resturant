import { NextResponse } from "next/server"

// In-memory storage reference (shared with the main orders route)
import { orders } from "@/lib/mock-data"

export async function GET() {
  // In a real app, you would fetch this from your database using Prisma
  // const pendingOrders = await prisma.order.findMany({
  //   where: { status: "PENDING" },
  //   include: { items: true },
  //   orderBy: { createdAt: 'asc' }
  // })

  // For now, just return all orders, sorted by creation date (newest first)
  const sortedOrders = [...orders].sort((a, b) => {
    return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
  })

  return NextResponse.json(sortedOrders)
}
